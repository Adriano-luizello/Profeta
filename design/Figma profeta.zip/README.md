
  # Dashboard com Chat Analytics

  This is a code bundle for Dashboard com Chat Analytics. The original project is available at https://www.figma.com/design/TZDp2vO86H6yEczwpdYejq/Dashboard-com-Chat-Analytics.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  